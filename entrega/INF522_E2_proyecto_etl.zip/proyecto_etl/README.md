# INF-522 · Evaluación 2 — ETL de compras públicas (Mercado Público + Banco Central)

ETL en Python orquestado con **Apache Airflow 3** (3.3.2, CeleryExecutor) que consume dos APIs públicas
chilenas, carga PostgreSQL 16 por capas (`raw → staging → dw → mart`, más `audit`) y calcula 6 KPIs.

| Fuente | Endpoint | Credencial |
|---|---|---|
| Mercado Público (ChileCompra) | `https://api.mercadopublico.cl/servicios/v1/publico/licitaciones.json` | Ticket (se pide con Clave Única en https://www.chilecompra.cl/api/) |
| Banco Central de Chile (BDE) | `https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx` | Token de la API (registro en https://si3.bcentral.cl/Siete/es/Siete/API) |

## Estructura
```
dags/
  dag_pipeline_bcch.py            DAG pipeline_bcch_etl            (lun-vie 10:00, ventana de 7 días)
  dag_pipeline_mercadopublico.py  DAG pipeline_mercadopublico_etl  (diario 06:00, catchup desde 01-10-2026)
  dag_pipeline_kpis.py            DAG pipeline_kpis_gestion        (Assets: ASSET_BCCH | ASSET_MP)
  pipeline_bcch.py                Etapas del ETL del Banco Central (Python puro, ejecutable sin Airflow)
  pipeline_mercadopublico.py      Etapas del ETL de Mercado Público (Python puro)
  pipeline_kpis.py                Cálculo de los 6 KPIs en SQL (copiado de sql/kpi/kpis.sql)
  comun_airflow.py                Conexión, credenciales enmascaradas, auditoría, callbacks y Assets
sql/ddl/00_init_meta.sh           Crea la base de metadatos de Airflow (airflow_meta)
sql/ddl/01_modelo.sql             DDL completo (esquemas, dimensiones, hechos, mart, audit,
                                  diccionario de datos con COMMENT ON y rol analista_kpi)
sql/kpi/kpis.sql                  Cálculo de indicadores (mart)
sql/consultas/consultas_evidencia.sql  Consultas de evidencia para el informe (carga, auditoría, KPIs)
docs/figuras/modelo_dimensional.png    Diagrama del modelo dimensional
docker-compose.yml, .env.example, requirements.txt
```

Cada ETL tiene seis tareas: `crear_modelo → validar_api → extract → transform → calidad → load`.
`calidad` es una compuerta: si falla, `load` no se ejecuta, no se carga nada y no se publica el Asset.
Al terminar bien, `load` publica su Asset y eso dispara `pipeline_kpis_gestion`
(`crear_modelo → verificar_frescura → calcular_kpis`).

## Requisitos
- Docker Desktop con al menos 4 GB de RAM (en Windows, con WSL2) y los puertos 8080 y 5433 libres.
- Credenciales propias: ticket de Mercado Público y token **activado** de la API del Banco Central.

## Cómo ejecutar
1. `cp .env.example .env` y completar claves (`MP_TICKET`, `BCCH_TOKEN`, contraseñas). **`.env` no se entrega.**
   El token del BCCh contiene `$`: escribirlo entre comillas simples (`BCCH_TOKEN='...'`).
2. Generar las dos claves de Airflow y ponerlas en `.env` (una sola vez; no cambiarlas después):
   ```bash
   python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"   # AIRFLOW_FERNET_KEY
   python -c "import secrets; print(secrets.token_urlsafe(32))"                                # AIRFLOW_JWT_SECRET
   ```
3. `docker compose up -d`. Al crear la base se aplica el DDL (`sql/ddl`) y `airflow-init` migra la base
   de metadatos, crea el usuario admin y registra la Connection `dw_postgres` y las Variables
   `mp_ticket` y `bcch_token` (visibles en Admin → Connections / Variables, cifradas con la Fernet key).
4. Airflow en http://localhost:8080 (usuario/clave de `.env`). Activar (unpause) los 3 DAGs.
5. Opcional (tope de detalles por run para cuidar la cuota de 10.000 consultas diarias del ticket):
   `docker compose exec airflow-scheduler airflow variables set mp_max_detalle 150`

Variables opcionales: `mp_base_url`, `bcch_base_url` (URL de cada API) y `mp_max_detalle` (150 por defecto).
No hay claves en el código: se leen de la Connection y las Variables al ejecutar cada tarea y se
enmascaran (`***`) en los logs.

## Indicadores de gestión (`sql/kpi/kpis.sql` → `mart.kpi_mensual`)
Pregunta de gestión: ¿qué tan eficiente, competitivo y transparente es el proceso de licitaciones del
Estado y cuánto se licita en términos reales? Todos se calculan **por mes** (`anio_mes` de la fecha de
movimiento) y se recalculan solos cuando cualquiera de los dos DAGs ETL publica su Asset.

| KPI | Objetivo / decisión que apoya | Fórmula | Fuente | Meta |
|---|---|---|---|---|
| KPI1 Tasa de adjudicación (%) | Eficiencia: cuántos procesos terminan en compra | adjudicadas / licitaciones con estado final × 100 | Mercado Público | ≥ 80 % |
| KPI2 Tasa de licitaciones desiertas (%) | Detectar procesos fallidos que obligan a relicitar | desiertas (estado 7) / con estado final × 100 | Mercado Público | ≤ 15 % |
| KPI3 Plazo promedio publicación-cierre (días) | Competencia: tiempo que tienen los proveedores para ofertar | promedio de `dias_publicacion_cierre` | Mercado Público | ≥ 10 días |
| KPI4 Monto estimado licitado (miles de UF) | Volumen de compra en términos reales, comparable entre meses | Σ `monto_estimado_uf` / 1.000 | Mercado Público + BCCh (UF) | Umbral de alerta: ±20 % respecto del mes anterior |
| KPI5 Licitaciones con monto estimado visible (%) | Transparencia del monto publicado | con monto informado / con detalle × 100 | Mercado Público | ≥ 50 % |
| KPI6 Concentración top-10 organismos (%) | Concentración del gasto en pocos compradores | participación de los 10 organismos con mayor monto en CLP | Mercado Público + BCCh (tipo de cambio) | ≤ 60 % |

`mart.top_organismos_mes` guarda el ranking que usa el KPI6 y `mart.v_contexto_economico_mes` el valor
promedio y la volatilidad de cada serie del BCCh por mes.

## Verificar que todo quedó bien
```bash
docker compose ps -a     # postgres y redis "healthy", airflow-init "Exited (0)", el resto "Up (healthy)"
docker compose exec airflow-scheduler airflow dags list-import-errors   # "No data found" = sin errores
docker compose exec airflow-scheduler airflow dags list                 # los 3 DAGs pipeline_*
```

## Conectarse a la base con DBeaver o pgAdmin
Host `localhost` · Puerto `5433` · Base `etl_bcc` · Usuario y clave: `POSTGRES_USER` / `POSTGRES_PASSWORD` del `.env`.
Para consultar los KPIs sin acceso a `raw` (datos personales) usar el rol de solo lectura `analista_kpi`.

## Reiniciar desde cero
`docker compose down -v` borra los contenedores **y la base de datos** de este proyecto. Al volver a
ejecutar `docker compose up -d`, el DDL se aplica de nuevo automáticamente.

## Respaldo de la base
```bash
docker compose exec postgres pg_dump -U etl -Fc -f /tmp/etl_bcc.dump etl_bcc
docker compose cp postgres:/tmp/etl_bcc.dump ../respaldo_etl_bcc.dump
```

## Recarga de un rango pasado
- UI: **Trigger** (Run Parameters) → `{"fecha_desde": "2026-10-01", "fecha_hasta": "2026-10-13"}` (ambos ETL).
- UI: **Trigger → Backfill**, o por CLI (un run por día del rango):
  `docker compose exec airflow-scheduler airflow backfill create --dag-id pipeline_mercadopublico_etl --from-date 2026-10-01 --to-date 2026-10-13 --reprocess-behavior completed`
  (`--to-date` no se incluye: este ejemplo crea los runs del 01-10 al 12-10; cada run procesa el día anterior a su fecha).
- Recarga histórica del BCCh (desde 2024, por las licitaciones publicadas ese año):
  `docker compose exec airflow-scheduler airflow dags trigger pipeline_bcch_etl -c '{"fecha_desde": "2024-01-01"}'`

Todas las cargas son idempotentes (`INSERT … ON CONFLICT`), re-ejecutar no duplica.

## Demostración de falla controlada
```bash
docker compose exec airflow-scheduler airflow variables set mp_base_url https://api.mercadopublico.cl/url-incorrecta.json
docker compose exec airflow-scheduler airflow dags trigger pipeline_mercadopublico_etl
# validar_api responde HTTP 404 -> up_for_retry y falla tras 3 intentos (~10 min por el backoff)
# filas RETRY/FAILED en audit.etl_audit; el DAG del BCCh y el de KPIs siguen ejecutándose
docker compose exec airflow-scheduler airflow variables delete mp_base_url   # restaura la URL por defecto
# en la UI: Clear sobre la tarea validar_api -> el run se recupera
```

## Consultas útiles
```sql
SELECT * FROM audit.etl_audit ORDER BY audit_id DESC LIMIT 20;
SELECT * FROM mart.kpi_mensual ORDER BY anio_mes, kpi_codigo;
SELECT * FROM mart.top_organismos_mes WHERE anio_mes = '2026-10';
```
Todas las consultas de evidencia del informe:
`docker compose exec -T postgres psql -U etl -d etl_bcc < sql/consultas/consultas_evidencia.sql`

## Ejecutar un ETL sin Airflow
Cada `pipeline_*.py` tiene un `main()` que ejecuta todas sus etapas en orden (útil para depurar):
```bash
PGHOST=localhost PGPORT=5433 PGDATABASE=etl_bcc PGUSER=etl PGPASSWORD=<clave> MP_TICKET=<ticket> python dags/pipeline_mercadopublico.py
```
